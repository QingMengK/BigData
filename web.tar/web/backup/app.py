import json

from flask import Flask, render_template
from flask_socketio import SocketIO
from flask.json import jsonify

from kafka import KafkaConsumer

from pyecharts import options as opts  # 新增加的
from pyecharts.charts import Bar
from pyecharts.charts import Map,Geo
from pyecharts.charts import Grid, Liquid
from pyecharts.commons.utils import JsCode
from pyecharts.globals import CurrentConfig, ThemeType
from pyecharts.charts import Pie
from pyecharts.charts import Gauge
import pyecharts

import numpy as np

import pandas as pd  # 新增加的

cnt1 = 0
cnt2 = 0
cnt3 = 0

date = list(map(str,pd.date_range('29/8/2015','11/11/2015'))) # 新增加的
for i in range(75):
    date[i] = date[i][0:10]
print(date)

df = pd.read_csv('/home/ldzh/resource_file/BigDataApplicationPractice/int.exp1/web/data/result_static.csv') # 新增加的
cat_all = []
value_all = []
buy_rate_all = []
click_rate_all = []
favorite_rate_all = []
for j in range(75):
    cat = []
    value = []
    for i in range(10):
        pare = df.iloc[j]['类别数量'+str(i+1)]
        pare = pare.replace(' ','').replace('(','').replace(')','').split(',')
        cat.append('商品类号'+pare[0])
        value.append(int(pare[1]))
    cat_all.append(cat)
    value_all.append(value)
    buy_rate = df.iloc[j]['商品购买率']
    buy_rate = round(buy_rate,2)
    buy_rate_all.append(buy_rate)
    click_rate = df.iloc[j]['商品点击率']/100
    #click_rate = round(click_rate,4)
    favorite_rate = df.iloc[j]['商品关注率']/100
    #favorite_rate = round(favorite_rate,4)
    click_rate_all.append(click_rate)
    favorite_rate_all.append(favorite_rate)

locate = ['辽宁','福建','四川','江苏','海南','贵州','山东','陕西','湖南','澳门','山西','吉林','甘肃','河北','香港','广西','安徽','宁夏','江西','上海市','云南','天津市 ','北京市','湖北',"\u91cd\u5e86",'新疆','台湾','内蒙古','黑龙江','浙江','青海','河南',"\u897f\u85cf",'广东']
app_price = [0,0,0,0,0,\
0,0,0,0,0,\
0,0,0,0,0,\
0,0,0,0,0,\
0,0,0,0,0,\
0,0,0,0,0,\
0,0,0,0]
list1 = [[locate[i],app_price[i]] for i in range(len(locate))]

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)
thread = None
consumer = KafkaConsumer('result')
data_list = []

def map_base() -> Map:
    global app_price,list1,data_list
    print(len(locate))
    print(len(app_price))
    list1 = [[locate[i],app_price[i]] for i in range(len(locate))]
    print(list1)
    m = (
        Map()
        .add("参与双十一人员的地理空间分布", list1, maptype="china")
        .set_global_opts(
            title_opts=opts.TitleOpts(title="参与双十一人员的地理空间分布"),
            visualmap_opts=opts.VisualMapOpts(max_=150)  #最大数据范围
        )
    )
    print('----------3-----------------')
    print(app_price)
    return m

def circle_base() -> Pie:
    global date,cat_all,value_all,cnt1
    #print(cat_all[1],value_all[1])
    cir = (
        Pie()
        .add(
            "",
            [list(z) for z in zip(cat_all[cnt1], value_all[cnt1])],
            radius=["40%", "60%"],
            label_opts=opts.LabelOpts(
                position="outside",
                formatter="{a|{a}}{abg|}\n{hr|}\n {b|{b}: }{c}  {per|{d}%}  ",
                background_color="#eee",
                border_color="#aaa",
                border_width=1,
                border_radius=4,
                rich={
                    "a": {"color": "#999", "lineHeight": 22, "align": "center"},
                    "abg": {
                        "backgroundColor": "#e3e3e3",
                        "width": "100%",
                        "align": "right",
                        "height": 22,
                        "borderRadius": [4, 4, 0, 0],
                    },
                    "hr": {
                        "borderColor": "#aaa",
                        "width": "100%",
                        "borderWidth": 0.5,
                        "height": 0,
                    },
                    "b": {"fontSize": 16, "lineHeight": 33},
                    "per": {
                        "color": "#eee",
                        "backgroundColor": "#334455",
                        "padding": [2, 4],
                        "borderRadius": 2,
                    },
                },
            ),
        )
        .set_global_opts(title_opts=opts.TitleOpts(title=date[cnt1]+"\n参与活动的\n前10类商品",pos_right= 'center',pos_left= 'center',pos_top='center',pos_bottom='center'))
    )
    print('----------circle-----------------')
    cnt1 = cnt1 + 1
    if cnt1 == 75:
        cnt1 = 0
    return cir


def instrum_base() -> Gauge:
    global date,buy_rate_all,cnt2
    ins = (
        Gauge()
        .add(
            series_name='商品购买率',            # 系列名称，用于 tooltip 的显示，legend 的图例筛选。
            data_pair=[['', buy_rate_all[cnt2]]],      # 系列数据项，格式为 [(key1, value1), (key2, value2)]
            radius='70%',                      # 仪表盘半径，可以是相对于容器高宽中较小的一项的一半的百分比，也可以是绝对的数值。
            axisline_opts=opts.AxisLineOpts(
                linestyle_opts=opts.LineStyleOpts(  # 坐标轴轴线配置项
                    color=[(0.3, "#67e0e3"), (0.7, "#37a2da"), (1, "#fd666d")],
                    width=30,
                )
            ),
            title_label_opts=opts.LabelOpts(          # 轮盘内标题文本项标签配置项
                font_size=35, color='blue', font_family='KaiTi'
            ),
            detail_label_opts=opts.LabelOpts(          # 轮盘内标题文本项标签配置项
                font_size=35, color='red', font_family='KaiTi'
            )
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(          # 标题配置项
                title=date[cnt2]+'商品购买率',
                title_textstyle_opts=opts.TextStyleOpts(
                    font_size=25, font_family='SimHei',
                    color='black', font_weight='bold',
                ),
            pos_right= 'center',pos_left= 'center',
            ),
            legend_opts=opts.LegendOpts(        # 图例配置项
                is_show=False
            ),
            tooltip_opts=opts.TooltipOpts(         # 提示框配置项
                is_show=True,
                formatter="{a} <br/>{b} : {c}%",
            )
        )
    )
    print('----------instrum----------------')
    cnt2 = cnt2 + 1
    if cnt2 == 75:
        cnt2 = 0
    return ins

def water_base() -> Liquid:
    global date,click_rate_all,favorite_rate_all,cnt3
    lq_1 = (
        Liquid()
        .add(
            series_name='商品点击率',        # 系列名称，用于 tooltip 的显示，legend 的图例筛选。
            data=[click_rate_all[cnt3]],               # 系列数据，格式为 [value1, value2, ....]
            center=['75%', '50%'],
            # 水球外形，有' circle', 'rect', 'roundRect', 'triangle', 'diamond', 'pin', 'arrow' 可选。
            # 默认 'circle'   也可以为自定义的 SVG 路径
            shape='circle',
            color=['yellow'],          # 波浪颜色   Optional[Sequence[str]] = None,
            is_animation=True,         # 是否显示波浪动画
            is_outline_show=False,     # 是否显示边框
        )
        .set_global_opts(title_opts=opts.TitleOpts(title='                '+date[cnt3]\
                                                   +'\n       商品关注率           商品点击率',\
                                                   title_textstyle_opts=opts.TextStyleOpts(font_size=30,color= '#0085c3')))
    )
    
    lq_2 = (
        Liquid()
        .add(
            series_name='商品关注率',
            data=[favorite_rate_all[cnt3]],
            center=['25%', '50%'],
            label_opts=opts.LabelOpts(
                font_size=50,
                position='inside'
            )
    
        )
    )
    
    grid = Grid(init_opts=opts.InitOpts()).add(lq_1, grid_opts=opts.GridOpts()).add(lq_2, grid_opts=opts.GridOpts())
    print('----------instrum----------------')
    cnt3 = cnt3 + 1
    if cnt3 == 75:
        cnt3 = 0
    return grid

def background_thread():
    global app_price
    for msg in consumer:
        data_json = msg.value.decode('utf8')
        data_json.strip('\'');
        data_list = data_json.split(',')
        app_price = data_list[13:47]        
        result = data_json
        print(result)
        socketio.emit('test_message',{'data':result})
        print('####')
        


@socketio.on('test_connect')
def connect(message):
    print(message)
    global thread
    if thread is None:
        thread = socketio.start_background_task(target=background_thread)
    socketio.emit('connected', {'data': 'Connected'})
    


@app.route("/")
def handle_mes():
    return render_template("index.html")

@app.route("/mapChart")
def get_map_chart():
    print('---------1-----------')
    m = map_base()
    print('---------4-----------')
    return m.dump_options_with_quotes()

@app.route("/circleChart")
def get_circle_chart():
    circle = circle_base()
    return circle.dump_options_with_quotes()

@app.route("/instrumChart")
def get_instrum_chart():
    instrum = instrum_base()
    return instrum.dump_options_with_quotes()

@app.route("/waterChart")
def get_water_chart():
    water = water_base()
    return water.dump_options_with_quotes()


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
    socketio.run(app,debug=True)
    
